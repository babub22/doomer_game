Included with the project are two sample files: 'test.obj' and 
'test.mtl'. These are examples of the wavefront obj file format.
'test.obj' contains the geometry definitions, while 'test.mtl'
contains the material definitions.

There are extensions to the parser to support common
raytracing objects. There is also support for lights and
camera data. See the example files for details on the
specifications.